# pnot0sThings
**Content mod for Lethal Company, made for my friends**

LethalLib is a required dependency for this mod to work

## List of items

* Speed Coil
  * increases player movement speed
  
![speed coil](https://github.com/user-attachments/assets/3aae0f96-226b-4165-a405-21a8f0c9ddd8)

* Gravity Coil
  * increases player jump height

![gravity coil](https://github.com/user-attachments/assets/eb2f36e0-78a5-4ca6-b7cd-f84ecbae776e)

* Colt 1911
  * its a gun

![colt 1911](https://github.com/user-attachments/assets/9e74f8c3-bc31-47da-ab4b-1a82988280cb)

* Rocket Propelled Grenade (RPG) Launcher

![faulty rpg](https://github.com/user-attachments/assets/42040f90-e54a-40bc-988a-d8f3c6b33168)

* Soda Bottle
  * Ordinary soda from you favorite local brand

![dolly garrafa](https://github.com/user-attachments/assets/757ec476-e085-4827-a3fe-6b05c6c63b75)

* Canned Soda
  * Prohibited old drink
  * Can get you really high

![zap soda](https://github.com/user-attachments/assets/4d7b233e-6d23-44e3-b33d-1624965ca061)

* Dollar bills
  * currently not in circulation

![dollar bill](https://github.com/user-attachments/assets/ff4c0a47-7f5d-4dc8-af1b-3fa380201e75)

* Vinyl Record
  * if only you had a record player
  * and it wasnt scratched

![album vinyl](https://github.com/user-attachments/assets/22e99d68-18e1-4822-b9e7-c243731c210a)

* Dingus
  * look at him
  * isnt he cute?

![dingus ember](https://github.com/user-attachments/assets/3b18dabe-6c75-4118-8112-b5be06af0fda)


## Model Credits
**All models were taken from Sketchfab, and all credits are given to their proper authors**

* Speed Coil (thestylecopycat): https://sketchfab.com/3d-models/speed-coil-roblox-02237efd74fc47b98ab57a41d1fc3cc3

* Gravity Coil (thestylecopycat): https://sketchfab.com/3d-models/gravity-coil-roblox-5bcba4a4f88d4e6cbf030c82698314fb

* Colt 1911 (legoingr): https://sketchfab.com/3d-models/colt-m1911-bcf398f3109a4d0ea384dcd3196a695e

* Rocket Propelled Grenade Launcher (hatt_): https://sketchfab.com/3d-models/minecraft-hl2-at4-3a508eed7770432694c21e555cf31b12

* Soda Bottle (Coelho): https://sketchfab.com/3d-models/garrafa-de-dolly-7bcdc37ca6f64f848b4e89cd37d8a6cb]

* Canned Soda (bolsonaro gamer): https://sketchfab.com/3d-models/latinha-refrigerante-whatsapp-92ec4209ca704610961d0e082f92e07b

* Dollar bills (hmzabanna): https://sketchfab.com/3d-models/stacks-of-money-3c9de90c6dc94b989b27d8de2341f1ac

* Vinyl Record (Mazou): https://sketchfab.com/3d-models/album-vinyl-01aaa615d80a47aeb9ce058bfe59164c

* Dingus ( bean(alwayshasbean) ): https://sketchfab.com/3d-models/maxwell-the-cat-dingus-2ca7f3c1957847d6a145fc35de9046b0




